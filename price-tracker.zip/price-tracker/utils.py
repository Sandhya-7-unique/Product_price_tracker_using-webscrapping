def get_product_price(url):
    # Scrape title and price, return as dict 
    product_data = get_product_price(url)
    print(product_data)